def bar():
  pass
