pub fn create_universe() { }
pub fn build_rocket() { }
pub fn build_shuttle() { }

pub fn main() {
    // Identifier here can be used for GoTo test
    create_universe();
    // Test completion
    build_
}
