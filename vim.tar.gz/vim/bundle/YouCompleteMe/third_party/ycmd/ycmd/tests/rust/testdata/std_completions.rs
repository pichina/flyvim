use std::path::Path;

pub fn main() {
  let program = Path::new( "/foo" );
  program.
}

