from goto_file3 import bar as foo
