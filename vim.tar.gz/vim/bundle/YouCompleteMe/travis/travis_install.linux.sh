# Linux installation

virtualenv -p python${YCMD_PYTHON_VERSION} ${YCMD_VENV_DIR}
